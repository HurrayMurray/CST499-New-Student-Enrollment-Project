<?php
echo "Test PHP file is working!";
?>